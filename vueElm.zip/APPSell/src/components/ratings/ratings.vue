<!--  -->
<template>
  <div>ratings</div>
</template>

<script type='text/ecmascript-6'>
export default {
  data () {
    return {
    };
  },

  components: {},

  methods: {}
}

</script>
<style lang='stylus' rel = 'stylesheet/stylus'>
</style>